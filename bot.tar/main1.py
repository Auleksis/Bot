import os
import subprocess
import json


def main():
    global project_name, path
    fpath = os.path.join(path, project_name)
    print(os.path.exists('\\user_data'))
    with open(os.path.join(fpath, 'form.json')) as input:
        raw_path = os.path.join(fpath, 'Output')

        if not os.path.exists(raw_path):
            os.makedirs(raw_path)

        data = json.load(input)

        make_canvas(data)

        make_memo(data)

        compile(raw_path, 'canvas')

        compile(raw_path, 'memo')

def compile(raw_path, name):
    global path, project_name

    filename = os.path.join(raw_path, (name + '.tex'))

    proc = subprocess.Popen(['pdflatex', filename])
    proc.communicate()

    os.remove(name + '.aux')
    os.remove(name + '.log')
    os.replace(name + '.pdf', os.path.join(path, project_name, 'Output', name + '.pdf'))

def make_canvas(data: dict):
    global project_name, path
    with open(os.path.join('CANVAS_T.txt'), encoding='utf-8') as f:
        text_data = f.read()
        print(text_data)

        for i in data.keys():
            if type(data[i]) == str:
                print(text_data.count('/'+ i + '/'))
                text_data = text_data.replace('/'+ i + '/', data[i])

        print(text_data)

    with open(os.path.join(path, project_name, 'Output', 'canvas.tex'), 'w', encoding='utf-8') as output:
        output.write(text_data)

def make_memo(data: dict):
    global project_name, path
    with open(os.path.join('MEMO_T.tex'), encoding='utf-8') as f:
        text_data = f.read()
        print(text_data)

        for i in data.keys():
            if type(data[i]) == str:
                print(text_data.count('/'+ i + '/'))
                text_data = text_data.replace('/'+ i + '/', data[i])
            elif type(data[i] == list):
                if data[i]:
                    text_data = text_data.replace('/' + i + '/', data[i][0])
                else:
                    remove_person_data(i, text_data)

        text_data = text_data.replace('|img_path|', os.path.join(path, project_name))
        print(text_data)

    with open(os.path.join(path, project_name, 'Output', 'memo.tex'), 'w', encoding='utf-8') as output:
        output.write(text_data)

def remove_person_data(question_id: str, text_data: str):
    d_array = text_data.split('\n')
    for i in range(len(d_array)):
        if d_array[i].count(question_id) != 0:
            for j in range(i - 1, i + 8):
                d_array.pop(j)



path = os.path.join('user_data')
project_name = '77037'
main()
#make_canvas()
